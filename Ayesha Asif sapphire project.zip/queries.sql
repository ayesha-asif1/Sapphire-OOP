
-- Products Table
CREATE TABLE products (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    price INT,
    category VARCHAR(50),
    subcategory VARCHAR(50)
);

-- Customers Table
CREATE TABLE customers (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50),
    password VARCHAR(100),
    phone VARCHAR(15),
    cnic VARCHAR(20),
    email VARCHAR(100)
);

-- Cart Items Table
CREATE TABLE cart_items (
    id SERIAL PRIMARY KEY,
    customer_id INT REFERENCES customers(id),
    product_id INT REFERENCES products(id),
    quantity INT
);

-- Orders Table
CREATE TABLE orders (
    id SERIAL PRIMARY KEY,
    order_id VARCHAR(20),
    customer_id INT REFERENCES customers(id),
    address VARCHAR(255),
    total_amount INT,
    order_date TIMESTAMP,
    status VARCHAR(20)
);

-- Order Items Table
CREATE TABLE order_items (
    id SERIAL PRIMARY KEY,
    order_id INT REFERENCES orders(id),
    product_id INT REFERENCES products(id),
    quantity INT,
    price INT
);

-- INSERT Sample Products
INSERT INTO products (name, price, category, subcategory) VALUES
('Embroidered Lawn Shirt', 2990, 'New In', 'stitched'),
('Classic Blue Kurta', 3990, 'Men', 'stitched'),
('Floral Printed Dupatta', 1890, 'Women', 'unstitched'),
('Sleepwear Pajama Set', 2590, 'New In', 'sleep wear'),
('Modest Abaya', 4990, 'Women', 'modest'),
('Mini Kurta - Son Edition', 2290, 'Mini Me', 'like daddy like son'),
('Chic Western Top', 2790, 'Women', 'west'),
('Noir - Eau de Parfum', 3490, 'Fragrances', 'for him');

-- INSERT Sample Customers
INSERT INTO customers (username, password, phone, cnic, email) VALUES
('ali', 'pass123', '03012345678', '3520212345671', 'ali@gmail.com'),
('sara_k', 'sara2024', '03001122334', '3310011223344', 'sara@gmail.com'),
('hassan07', 'hello@123', '03129988776', '3740576432109', 'hassan@yahoo.com'),
('fatima92', 'passfatima', '03215544332', '4210167890123', 'fatima@hotmail.com'),
('ali_beta', 'betapass', '03334433221', '3610212345678', 'ali@example.com'),
('ayesha_a', 'ayesha2025', '03456677889', '3230112233445', 'ayesha@gmail.com');

-- INSERT Cart Items
INSERT INTO cart_items (customer_id, product_id, quantity) VALUES
(1, 1, 1),
(1, 2, 1),
(2, 3, 1),
(3, 4, 2),
(4, 7, 1);

-- INSERT Orders
INSERT INTO orders (order_id, customer_id, address, total_amount, order_date, status) VALUES
('20250609101001', 1, '123 Street Lahore', 6980, '2025-06-09 10:10:01', 'Pending'),
('20250609101500', 2, 'House 9, Islamabad', 1890, '2025-06-09 10:15:00', 'Completed'),
('20250609102500', 4, 'Flat 3A, Peshawar', 2790, '2025-06-09 10:25:00', 'Pending'),
('20250609103015', 3, 'House 88, Quetta', 3490, '2025-06-09 10:30:15', 'Pending'),
('20250609104010', 6, 'Sapphire HQ Lahore', 3990, '2025-06-09 10:40:10', 'Pending');

-- INSERT Order Items
INSERT INTO order_items (order_id, product_id, quantity, price) VALUES
(1, 2, 1, 3990),
(1, 1, 1, 2990),
(2, 3, 1, 1890),
(3, 7, 1, 2790),
(4, 8, 1, 3490),
(5, 2, 1, 3990);

SELECT o.order_id, c.username, o.total_amount, o.status, o.order_date
FROM orders o
INNER JOIN customers c ON o.customer_id = c.id;


SELECT c.username, p.name, ci.quantity, (p.price * ci.quantity) AS total_price
FROM cart_items ci
INNER JOIN customers c ON ci.customer_id = c.id
INNER JOIN products p ON ci.product_id = p.id;

SELECT o.order_id, p.name AS product_name, oi.quantity, oi.price
FROM order_items oi
INNER JOIN orders o ON oi.order_id = o.id
INNER JOIN products p ON oi.product_id = p.id;


SELECT c.username, SUM(p.price * ci.quantity) AS cart_total
FROM customers c
LEFT JOIN cart_items ci ON c.id = ci.customer_id
LEFT JOIN products p ON ci.product_id = p.id
GROUP BY c.username;


SELECT c.username, SUM(o.total_amount) AS total_spent
FROM customers c
LEFT JOIN orders o ON c.id = o.customer_id
GROUP BY c.username
ORDER BY total_spent DESC;


SELECT category, COUNT(*) AS total_products
FROM products
GROUP BY category;

SELECT * FROM products
WHERE subcategory ILIKE 'stitched';

SELECT o.order_id, c.username, o.status
FROM orders o
RIGHT JOIN customers c ON o.customer_id = c.id
WHERE o.status = 'Pending' OR o.status IS NULL;

