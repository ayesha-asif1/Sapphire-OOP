#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <limits>   
#include <iomanip>  
#include <stdexcept> 
#include <algorithm> 
#include <ctime>    
#include <regex>   

using namespace std;


class Product {
protected:
    string name;
    double price;
    string subCategory;

public:
    Product() {}
    Product(string n, double p, string subCat) : name(n), price(p), subCategory(subCat) {}

    virtual void display() const {
        // Improved formatting for product display in tables
        cout << left << setw(25) << name
             << setw(15) << fixed << setprecision(2) << price
             << setw(25) << subCategory << "\n";
    }

    string getName() const { return name; }
    string getSubCategory() const { return subCategory; }
    double getPrice() const { return price; }

    void update(string n, double p, string subCat) {
        name = n;
        price = p;
        subCategory = subCat;
    }

    // Serialize for file
    string serialize() const {
        return name + "|" + to_string(price) + "|" + subCategory;
    }

    // Deserialize for file with error handling for stod
    static Product deserialize(const string& line) {
        size_t pos1 = line.find('|');
        size_t pos2 = line.find('|', pos1 + 1);

        // Basic validation for delimiters
        if (pos1 == string::npos || pos2 == string::npos || pos1 >= pos2) {
            cerr << "Warning: Malformed line in product file (missing delimiters or invalid structure): '" << line << "'. Skipping or creating default product.\n";
            return Product("CORRUPT_PRODUCT_NAME", 0.0, "CORRUPT_SUBCATEGORY"); // Return a default/invalid product
        }

        string n = line.substr(0, pos1);
        string price_str = line.substr(pos1 + 1, pos2 - pos1 - 1);
        string sub = line.substr(pos2 + 1);
        double p = 0.0; // Default price in case of conversion failure

        try {
            p = stod(price_str);
        } catch (const std::invalid_argument& e) {
            cerr << "Warning: Invalid price format for product '" << n << "' in line: '" << line << "'. Using 0.0 for price. Error: " << e.what() << "\n";
            p = 0.0; // Ensure price is 0.0 if conversion fails
        } catch (const std::out_of_range& e) {
            cerr << "Warning: Price out of range for product '" << n << "' in line: '" << line << "'. Using 0.0 for price. Error: " << e.what() << "\n";
            p = 0.0; // Ensure price is 0.0 if out of range
        }

        return Product(n, p, sub);
    }
};

// Derived classes for categories (no extra members for now)
class NewIn : public Product {
public:
    NewIn() {}
    NewIn(string n, double p, string subCat) : Product(n, p, subCat) {}
};
class Men : public Product {
public:
    Men() {}
    Men(string n, double p, string subCat) : Product(n, p, subCat) {}
};
class Women : public Product {
public:
    Women() {}
    Women(string n, double p, string subCat) : Product(n, p, subCat) {}
};
class MiniMe : public Product {
public:
    MiniMe() {}
    MiniMe(string n, double p, string subCat) : Product(n, p, subCat) {}
};
class Fragrances : public Product {
public:
    Fragrances() {}
    Fragrances(string n, double p, string subCat) : Product(n, p, subCat) {}
};

// ---------------------- CartItem & Cart Classes ----------------------
class CartItem {
public:
    string name;
    double price;
    string subCategory;

    CartItem(string n, double p, string sub) : name(n), price(p), subCategory(sub) {}

    void display() const {
        // Improved formatting for cart item display
        cout << left << setw(25) << name
             << setw(15) << fixed << setprecision(2) << price
             << setw(25) << subCategory << "\n";
    }

    string serialize() const {
        return name + "|" + to_string(price) + "|" + subCategory;
    }

    // Deserialize for file with error handling for stod
    static CartItem deserialize(const string& line) {
        size_t pos1 = line.find('|');
        size_t pos2 = line.find('|', pos1 + 1);

        if (pos1 == string::npos || pos2 == string::npos || pos1 >= pos2) {
            cerr << "Warning: Malformed line in cart file (missing delimiters or invalid structure): '" << line << "'. Skipping or creating default cart item.\n";
            return CartItem("CORRUPT_ITEM_NAME", 0.0, "CORRUPT_SUBCATEGORY"); // Return a default/invalid item
        }

        string n = line.substr(0, pos1);
        string price_str = line.substr(pos1 + 1, pos2 - pos1 - 1);
        string sub = line.substr(pos2 + 1);
        double p = 0.0; // Default price in case of conversion failure

        try {
            p = stod(price_str);
        } catch (const std::invalid_argument& e) {
            cerr << "Warning: Invalid price format for cart item '" << n << "' in line: '" << line << "'. Using 0.0 for price. Error: " << e.what() << "\n";
            p = 0.0;
        } catch (const std::out_of_range& e) {
            cerr << "Warning: Price out of range for cart item '" << n << "' in line: '" << line << "'. Using 0.0 for price. Error: " << e.what() << "\n";
            p = 0.0;
        }

        return CartItem(n, p, sub);
    }
};

class Cart {
private:
    vector<CartItem> items;

public:
    void addItem(const CartItem& item) {
        items.push_back(item);
        cout << "Added to cart successfully.\n";
    }

    void viewCart() const {
        if (items.empty()) {
            cout << "\n--- Your Cart ---\n";
            cout << "Cart is empty.\n";
            cout << "-----------------\n";
            return;
        }
        cout << "\n--- Your Cart ---\n";
        cout << left << setw(25) << "Item Name" << setw(15) << "Price (Rs)" << setw(25) << "Subcategory" << "\n";
        cout << string(65, '-') << "\n";
        for (const auto& item : items) {
            item.display();
        }
        cout << string(65, '-') << "\n";
        cout << left << setw(40) << "Total Amount:" << fixed << setprecision(2) << getTotal() << "\n";
        cout << "-----------------\n";
    }

    double getTotal() const {
        double total = 0;
        for (const auto& item : items) {
            total += item.price;
        }
        return total;
    }

    void checkout() const {
        if (items.empty()) {
            cout << "\nYour cart is empty. Cannot checkout.\n";
            return;
        }
        cout << "\n--- Checkout Summary ---\n";
        cout << left << setw(25) << "Item Name" << setw(15) << "Price (Rs)" << setw(25) << "Subcategory" << "\n";
        cout << string(65, '-') << "\n";
        for (const auto& item : items) {
            item.display();
        }
        cout << string(65, '-') << "\n";
        cout << left << setw(40) << "Total Amount:" << fixed << setprecision(2) << getTotal() << "\n";
        cout << "Thank you for shopping with us!\n";
        cout << "------------------------\n";
    }

    bool isEmpty() const {
        return items.empty();
    }

    const vector<CartItem>& getItems() const { // New: Getter for cart items
        return items;
    }

    void clearCart() { // New: Function to clear cart
        items.clear();
    }

    void saveToFile(const string& filename) {
        ofstream fout(filename);
        if (!fout.is_open()) {
            cerr << "Error: Could not open " << filename << " for saving cart.\n";
            return;
        }
        for (const auto& item : items) {
            fout << item.serialize() << "\n";
        }
        fout.close();
    }

    void loadFromFile(const string& filename) {
        items.clear();
        ifstream fin(filename);
        if (!fin.is_open()) {
            // File might not exist yet, especially on first run. Not an error.
            return;
        }
        string line;
        while (getline(fin, line)) {
            if (!line.empty()) {
                items.push_back(CartItem::deserialize(line));
            }
        }
        fin.close();
    }
};

// ---------------------- User Base Class (Abstract) ----------------------
class User {
protected:
    string username;
    string password;
public:
    User(string uname, string pass) : username(uname), password(pass) {}
    virtual ~User() = default; // Virtual destructor for base class

    string getUsername() const { return username; }
    bool checkPassword(string pass) const { return password == pass; }

    // Pure virtual function - must be implemented by derived classes
    virtual void displayMenu() = 0;

    // Serialize for file storage
    virtual string serialize() const {
        return username + "|" + password;
    }
};

// ---------------------- RegisteredCustomer Class ----------------------
class RegisteredCustomer : public User {
private:
    string phoneNumber;
    string cnic;
    string email;

public:
    RegisteredCustomer(string uname, string pass, string phone, string c, string e)
        : User(uname, pass), phoneNumber(phone), cnic(c), email(e) {}

    void displayMenu() override {
        // This will be replaced by the customerMenu() in the main program logic
        cout << "Registered Customer Menu (handled by Customer class later).\n";
    }

    string getPhoneNumber() const { return phoneNumber; }
    string getCnic() const { return cnic; }
    string getEmail() const { return email; }

    // Override serialize to include new fields
    string serialize() const override {
        return username + "|" + password + "|" + phoneNumber + "|" + cnic + "|" + email;
    }

    // Static method to deserialize a RegisteredCustomer from a line
    static RegisteredCustomer deserialize(const string& line) {
        size_t pos1 = line.find('|');
        size_t pos2 = line.find('|', pos1 + 1);
        size_t pos3 = line.find('|', pos2 + 1);
        size_t pos4 = line.find('|', pos3 + 1);

        if (pos1 == string::npos || pos2 == string::npos || pos3 == string::npos || pos4 == string::npos) {
            cerr << "Warning: Malformed line in customer file: '" << line << "'. Skipping.\n";
            // Return a default or invalid customer
            return RegisteredCustomer("CORRUPT_USER", "CORRUPT_PASS", "", "", "");
        }
        string uname = line.substr(0, pos1);
        string pass = line.substr(pos1 + 1, pos2 - pos1 - 1);
        string phone = line.substr(pos2 + 1, pos3 - pos2 - 1);
        string c = line.substr(pos3 + 1, pos4 - pos3 - 1);
        string e = line.substr(pos4 + 1);
        return RegisteredCustomer(uname, pass, phone, c, e);
    }
};

// ---------------------- PlaceOrder Class ----------------------
class PlaceOrder {
private:
    string orderId;
    string customerEmail;
    string shippingAddress;
    string customerUsername;
    vector<CartItem> orderedItems;
    double totalAmount;
    string orderDate;
    string status; // e.g., "Pending", "Completed", "Cancelled"

public:
    PlaceOrder(string custUname, const vector<CartItem>& items, double total, string email, string address)
        : customerUsername(custUname), orderedItems(items), totalAmount(total), customerEmail(email), shippingAddress(address), status("Pending") {
        // Generate a simple order ID (timestamp based)
        time_t now = time(0);
        tm* ltm = localtime(&now);
        char buffer[80];
        strftime(buffer, sizeof(buffer), "%Y%m%d%H%M%S", ltm);
        orderId = string(buffer);
        strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", ltm);
        orderDate = string(buffer);
    }

    string serialize() const {
        string item_data;
        for (const auto& item : orderedItems) {
            item_data += item.serialize() + ";"; // Use semicolon to separate items
        }
        // Remove trailing semicolon if any
        if (!item_data.empty()) {
            item_data.pop_back();
        }
        return orderId + "|" + customerUsername + "|" + to_string(totalAmount) + "|" + orderDate + "|" + status + "|" + customerEmail + "|" + shippingAddress + "|" + item_data;
    }

    static PlaceOrder deserialize(const string& line) {
        size_t pos1 = line.find('|');
        size_t pos2 = line.find('|', pos1 + 1);
        size_t pos3 = line.find('|', pos2 + 1);
        size_t pos4 = line.find('|', pos3 + 1);
        size_t pos5 = line.find('|', pos4 + 1);
        size_t pos6 = line.find('|', pos5 + 1);
        size_t pos7 = line.find('|', pos6 + 1);

        if (pos1 == string::npos || pos2 == string::npos || pos3 == string::npos || pos4 == string::npos || pos5 == string::npos || pos6 == string::npos || pos7 == string::npos) {
            cerr << "Warning: Malformed line in order file: '" << line << "'. Skipping.\n";
            return PlaceOrder("CORRUPT_CUSTOMER", {}, 0.0, "", ""); // Updated default constructor call
        }

        string oId = line.substr(0, pos1);
        string custUname = line.substr(pos1 + 1, pos2 - pos1 - 1);
        double total = stod(line.substr(pos2 + 1, pos3 - pos2 - 1));
        string oDate = line.substr(pos3 + 1, pos4 - pos3 - 1);
        string stat = line.substr(pos4 + 1, pos5 - pos4 - 1);
        string email = line.substr(pos5 + 1, pos6 - pos5 - 1); // New
        string address = line.substr(pos6 + 1, pos7 - pos6 - 1); // New
        string item_data_str = line.substr(pos7 + 1);

        vector<CartItem> items;
        size_t start = 0;
        size_t end = item_data_str.find(';');
        while (end != string::npos) {
            items.push_back(CartItem::deserialize(item_data_str.substr(start, end - start)));
            start = end + 1;
            end = item_data_str.find(';', start);
        }
        if (start < item_data_str.length()) {
            items.push_back(CartItem::deserialize(item_data_str.substr(start)));
        }

        PlaceOrder order(custUname, items, total, email, address);
        order.orderId = oId;
        order.orderDate = oDate;
        order.status = stat;
        return order;
    }

    void display() const {
        // Improved formatting for order display
        cout << "\n--------------------------------------------------\n";
        cout << left << setw(15) << "Order ID:" << orderId << "\n";
        cout << left << setw(15) << "Customer:" << customerUsername << "\n";
        cout << left << setw(15) << "Order Date:" << orderDate << "\n";
        cout << left << setw(15) << "Status:" << status << "\n";
        cout << left << setw(15) << "Email:" << customerEmail << "\n";
        cout << left << setw(15) << "Address:" << shippingAddress << "\n";
        cout << "--------------------------------------------------\n";
        cout << left << setw(25) << "Item Name" << setw(15) << "Price (Rs)" << setw(25) << "Subcategory" << "\n";
        cout << string(65, '-') << "\n";
        for (const auto& item : orderedItems) {
            item.display();
        }
        cout << string(65, '-') << "\n";
        cout << left << setw(40) << "Total Amount:" << fixed << setprecision(2) << totalAmount << "\n";
        cout << "--------------------------------------------------\n";
    }
};

// ---------------------- Admin Class ----------------------
class Admin {
private:
    string username = "Ayesha Asif";
    string password = "ayesha";

public:
    vector<NewIn> newInList;
    vector<Men> menList;
    vector<Women> womenList;
    vector<MiniMe> miniMeList;
    vector<Fragrances> fragranceList;
    vector<RegisteredCustomer> registeredCustomers; // New: To store registered customers
    vector<PlaceOrder> orders; // New: To store placed orders

    // File paths for persistence
    const string newInFile = "newin.txt";
    const string menFile = "men.txt";
    const string womenFile = "women.txt";
    const string miniMeFile = "minime.txt";
    const string fragranceFile = "fragrance.txt";
    const string customerFile = "customers.txt"; // New file for customers
    const string ordersFile = "orders.txt"; // New file for orders
    const string cartFile = "cart.txt"; // Cart file

    Admin() {
        // Removed call to clearAllDataFiles() here
        loadAll();
        loadCustomers(); // Load registered customers on startup
        loadOrders(); // Load orders on startup
    }

    // This function can still be called manually if needed for a complete reset
    void clearAllDataFiles() {
        ofstream ofs;

        ofs.open(newInFile, ofstream::out | ofstream::trunc);
        if (ofs.is_open()) ofs.close(); else cerr << "Warning: Could not clear " << newInFile << "\n";

        ofs.open(menFile, ofstream::out | ofstream::trunc);
        if (ofs.is_open()) ofs.close(); else cerr << "Warning: Could not clear " << menFile << "\n";

        ofs.open(womenFile, ofstream::out | ofstream::trunc);
        if (ofs.is_open()) ofs.close(); else cerr << "Warning: Could not clear " << womenFile << "\n";

        ofs.open(miniMeFile, ofstream::out | ofstream::trunc);
        if (ofs.is_open()) ofs.close(); else cerr << "Warning: Could not clear " << miniMeFile << "\n";

        ofs.open(fragranceFile, ofstream::out | ofstream::trunc);
        if (ofs.is_open()) ofs.close(); else cerr << "Warning: Could not clear " << fragranceFile << "\n";

        ofs.open(customerFile, ofstream::out | ofstream::trunc);
        if (ofs.is_open()) ofs.close(); else cerr << "Warning: Could not clear " << customerFile << "\n";

        ofs.open(ordersFile, ofstream::out | ofstream::trunc);
        if (ofs.is_open()) ofs.close(); else cerr << "Warning: Could not clear " << ordersFile << "\n";
        
        ofs.open(cartFile, ofstream::out | ofstream::trunc);
        if (ofs.is_open()) ofs.close(); else cerr << "Warning: Could not clear " << cartFile << "\n";

        cout << "All data files cleared manually.\n"; // Changed message
    }

    void saveAll() {
        saveCategory(newInFile, newInList);
        saveCategory(menFile, menList);
        saveCategory(womenFile, womenList);
        saveCategory(miniMeFile, miniMeList);
        saveCategory(fragranceFile, fragranceList);
        saveCustomers(); // Save registered customers
        saveOrders(); // Save orders
    }

    void loadAll() {
        loadCategory(newInFile, newInList);
        loadCategory(menFile, menList);
        loadCategory(womenFile, womenList);
        loadCategory(miniMeFile, miniMeList);
        loadCategory(fragranceFile, fragranceList);
        // loadCustomers() and loadOrders() are called separately in constructor
    }

    template<typename T>
    void saveCategory(const string& filename, const vector<T>& list) {
        ofstream fout(filename);
        if (!fout.is_open()) {
            cerr << "Error: Could not open " << filename << " for saving products.\n";
            return;
        }
        for (const auto& p : list) {
            fout << p.serialize() << "\n";
        }
        fout.close();
    }

    template<typename T>
    void loadCategory(const string& filename, vector<T>& list) {
        list.clear();
        ifstream fin(filename);
        if (!fin.is_open()) {
            // File might not exist yet on first run. Not an error.
            return;
        }
        string line;
        while (getline(fin, line)) {
            if (!line.empty()) {
                Product p = Product::deserialize(line);
                // Only add if it's not a "corrupt" placeholder product
                if (p.getName() != "CORRUPT_PRODUCT_NAME") {
                    list.push_back(T(p.getName(), p.getPrice(), p.getSubCategory()));
                }
            }
        }
        fin.close();
    }

    void saveCustomers() {
        ofstream fout(customerFile);
        if (!fout.is_open()) {
            cerr << "Error: Could not open " << customerFile << " for saving customers.\n";
            return;
        }
        for (const auto& cust : registeredCustomers) {
            fout << cust.serialize() << "\n";
        }
        fout.close();
    }

    void loadCustomers() {
        registeredCustomers.clear();
        ifstream fin(customerFile);
        if (!fin.is_open()) {
            return; // File might not exist yet
        }
        string line;
        while (getline(fin, line)) {
            if (!line.empty()) {
                RegisteredCustomer rc = RegisteredCustomer::deserialize(line);
                if (rc.getUsername() != "CORRUPT_USER") { // Check for corrupt users
                    registeredCustomers.push_back(rc);
                }
            }
        }
        fin.close();
    }

    void saveOrders() {
        ofstream fout(ordersFile);
        if (!fout.is_open()) {
            cerr << "Error: Could not open " << ordersFile << " for saving orders.\n";
            return;
        }
        for (const auto& order : orders) {
            fout << order.serialize() << "\n";
        }
        fout.close();
    }

    void loadOrders() {
        orders.clear();
        ifstream fin(ordersFile);
        if (!fin.is_open()) {
            return; // File might not exist yet
        }
        string line;
        while (getline(fin, line)) {
            if (!line.empty()) {
                orders.push_back(PlaceOrder::deserialize(line));
            }
        }
        fin.close();
    }

    string chooseSubCategory(const vector<string>& options) {
        for (size_t i = 0; i < options.size(); ++i) {
            cout << i + 1 << ". " << options[i] << endl;
        }
        int subChoice;
        cout << "Choice: ";
        while (!(cin >> subChoice)) { // Input validation loop
            cout << "Invalid input. Please enter a number: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // clear input buffer
        if (subChoice >= 1 && subChoice <= options.size()) {
            return options[subChoice - 1];
        } else {
            cout << "Invalid subcategory choice. Using 'Unknown'.\n"; // Changed to "Using"
            return "Unknown";
        }
    }

    bool login(string user, string pass) {
        return user == username && pass == password;
    }

    // New: Register customer function
    void registerCustomer() {
        string username, password, phone, cnic, email;
        cout << "\n--- Customer Registration ---\n";
        cout << "Enter desired username: ";
        getline(cin, username);

        // Check if username already exists
        for (const auto& cust : registeredCustomers) {
            if (cust.getUsername() == username) {
                cout << "Username already exists. Please choose a different one.\n";
                return;
            }
        }

        cout << "Enter desired password: ";
        getline(cin, password);

        // Phone number validation
        regex phone_regex("^03\\d{2}-\\d{7}$"); // Format: 03XX-XXXXXXX
        cout << "Enter Phone Number (e.g., 0300-1234567): ";
        while (true) {
            getline(cin, phone);
            if (regex_match(phone, phone_regex)) {
                break;
            } else {
                cout << "Invalid phone number format. Please use 03XX-XXXXXXX format: ";
            }
        }

        // CNIC validation
        regex cnic_regex("^\\d{13}$"); // Exactly 13 digits
        cout << "Enter CNIC (13 digits, e.g., 1234567890123): ";
        while (true) {
            getline(cin, cnic);
            if (regex_match(cnic, cnic_regex)) {
                break;
            } else {
                cout << "Invalid CNIC format. Please enter exactly 13 digits: ";
            }
        }

        // Email validation
        regex email_regex(R"(^[^@\s]+@[^@\s]+\.[^@\s]+$)"); // Basic email format
        cout << "Enter Email (e.g., user@example.com): ";
        while (true) {
            getline(cin, email);
            if (regex_match(email, email_regex)) {
                break;
            } else {
                cout << "Invalid email format. Please enter a valid email (e.g., user@example.com): ";
            }
        }

        registeredCustomers.emplace_back(username, password, phone, cnic, email);
        saveCustomers();
        cout << "Registration successful! You can now log in.\n";
    }

    // New: Customer login function for registered users
    bool customerLogin(string user, string pass) {
        for (const auto& cust : registeredCustomers) {
            if (cust.getUsername() == user && cust.checkPassword(pass)) {
                return true;
            }
        }
        return false;
    }

    RegisteredCustomer* findCustomerByUsername(const string& username) {
        for (auto& cust : registeredCustomers) {
            if (cust.getUsername() == username) {
                return &cust;
            }
        }
        return nullptr;
    }

    void addProduct() {
        int choice;
        cout << "\n--- Add New Product ---\n";
        cout << "Select Category to Add Product:\n";
        cout << "1. New In\n2. Men\n3. Women\n4. Mini Me\n5. Fragrances\n6. Cancel\nChoice: "; // Added cancel option
        while (!(cin >> choice)) { // Input validation loop
            cout << "Invalid input. Please enter a number: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // clear input buffer

        if (choice == 6) { // Handle cancel
            cout << "Product addition cancelled.\n";
            return;
        }

        string name;
        double price;
        string subCat;

        // Common input prompts
        cout << "Enter Product Name: ";
        getline(cin, name);
        cout << "Enter Price: ";
        while (!(cin >> price) || price < 0) { // Input validation for price (non-negative)
            cout << "Invalid input. Please enter a positive number for price: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        switch (choice) {
            case 1: {
                vector<string> options = {"stitched", "unstitched", "west", "sleep wear"};
                cout << "Select Subcategory:\n";
                subCat = chooseSubCategory(options);
                newInList.emplace_back(name, price, subCat);
                break;
            }
            case 2: {
                vector<string> options = {"stitched", "unstitched"};
                cout << "Select Subcategory:\n";
                subCat = chooseSubCategory(options);
                menList.emplace_back(name, price, subCat);
                break;
            }
            case 3: {
                vector<string> options = {"ready to wear", "stitched", "unstitched", "modest", "west"};
                cout << "Select Subcategory:\n";
                subCat = chooseSubCategory(options);
                womenList.emplace_back(name, price, subCat);
                break;
            }
            case 4: {
                vector<string> options = {"like mommy like me", "like daddy like son"};
                cout << "Select Subcategory:\n";
                subCat = chooseSubCategory(options);
                miniMeList.emplace_back(name, price, subCat);
                break;
            }
            case 5: {
                vector<string> options = {"for her", "for him"};
                cout << "Select Subcategory:\n";
                subCat = chooseSubCategory(options);
                fragranceList.emplace_back(name, price, subCat);
                break;
            }
            default:
                cout << "Invalid category selection.\n";
                return; // Exit function if category is invalid
        }
        saveAll();
        cout << "Product added successfully.\n";
    }

    void viewProducts() {
        cout << "\n--- All Products ---";

        auto printHeader = []() {
            cout << left << setw(25) << "Product Name" << setw(15) << "Price (Rs)" << setw(25) << "Subcategory" << "\n";
            cout << string(65, '-') << "\n";
        };

        // Check if lists are empty before printing headers to avoid empty sections
        if (!newInList.empty()) {
            cout << "\n[New In Products]:\n";
            printHeader();
            for (auto &p : newInList) p.display();
            cout << string(65, '-') << "\n";
        } else { cout << "\n[New In Products]: No products.\n"; }

        if (!menList.empty()) {
            cout << "\n[Men's Products]:\n";
            printHeader();
            for (auto &p : menList) p.display();
            cout << string(65, '-') << "\n";
        } else { cout << "\n[Men's Products]: No products.\n"; }

        if (!womenList.empty()) {
            cout << "\n[Women's Products]:\n";
            printHeader();
            for (auto &p : womenList) p.display();
            cout << string(65, '-') << "\n";
        } else { cout << "\n[Women's Products]: No products.\n"; }

        if (!miniMeList.empty()) {
            cout << "\n[Mini Me Products]:\n";
            printHeader();
            for (auto &p : miniMeList) p.display();
            cout << string(65, '-') << "\n";
        } else { cout << "\n[Mini Me Products]: No products.\n"; }

        if (!fragranceList.empty()) {
            cout << "\n[Fragrances Products]:\n";
            printHeader();
            for (auto &p : fragranceList) p.display();
            cout << string(65, '-') << "\n";
        } else { cout << "\n[Fragrances Products]: No products.\n"; }
        cout << "---------------------\n";
    }

    void deleteProduct() {
        cout << "\n--- Delete Product ---\n";
        cout << "Enter product name to delete: ";
        string name;
        getline(cin, name);

        bool found = false;
        auto tryDelete = [&](auto& list) {
            for (auto it = list.begin(); it != list.end(); ++it) {
                if (it->getName() == name) {
                    list.erase(it);
                    found = true;
                    return; // Exit after finding and deleting
                }
            }
        };

        tryDelete(newInList);
        if (!found) tryDelete(menList);
        if (!found) tryDelete(womenList);
        if (!found) tryDelete(miniMeList);
        if (!found) tryDelete(fragranceList);

        if (found) {
            saveAll();
            cout << "Product '" << name << "' deleted successfully.\n";
        } else {
            cout << "Product '" << name << "' not found.\n";
        }
        cout << "----------------------\n";
    }

    void updateProduct() {
        cout << "\n--- Update Product ---\n";
        cout << "Enter product name to update: ";
        string name;
        getline(cin, name);

        bool found = false;

        auto tryUpdate = [&](auto& list) {
            for (auto& p : list) {
                if (p.getName() == name) {
                    cout << "Found product '" << name << "'.\n";
                    cout << "Enter new name (current: " << p.getName() << "): ";
                    string newName;
                    getline(cin, newName);
                    if (newName.empty()) newName = p.getName(); // Keep old name if new is empty

                    cout << "Enter new price (current: Rs " << fixed << setprecision(2) << p.getPrice() << "): ";
                    double newPrice;
                    string priceInput;
                    getline(cin, priceInput);
                    if (priceInput.empty()) {
                        newPrice = p.getPrice(); // Keep old price if new is empty
                    } else {
                        try {
                            newPrice = stod(priceInput);
                            if (newPrice < 0) { // Validate positive price
                                cout << "Price cannot be negative. Keeping old price.\n";
                                newPrice = p.getPrice();
                            }
                        } catch (const std::invalid_argument&) {
                            cout << "Invalid price format. Keeping old price.\n";
                            newPrice = p.getPrice();
                        } catch (const std::out_of_range&) {
                            cout << "Price value out of range. Keeping old price.\n";
                            newPrice = p.getPrice();
                        }
                    }

                    cout << "Enter new subcategory (current: " << p.getSubCategory() << "): ";
                    string newSubCat;
                    getline(cin, newSubCat);
                    if (newSubCat.empty()) newSubCat = p.getSubCategory(); // Keep old subcategory if new is empty

                    p.update(newName, newPrice, newSubCat);
                    found = true;
                    return;
                }
            }
        };

        tryUpdate(newInList);
        if (!found) tryUpdate(menList);
        if (!found) tryUpdate(womenList);
        if (!found) tryUpdate(miniMeList);
        if (!found) tryUpdate(fragranceList);

        if (found) {
            saveAll();
            cout << "Product '" << name << "' updated successfully.\n";
        } else {
            cout << "Product '" << name << "' not found.\n";
        }
        cout << "----------------------\n";
    }

    void adminMenu() {
        while (true) {
            cout << "\n--- Admin Panel ---\n";
            cout << "1. Add Product\n2. View Products\n3. Update Product\n4. Delete Product\n5. View All Orders\n6. Logout\nChoice: ";
            int choice;
            while (!(cin >> choice)) {
                cout << "Invalid input. Please enter a number: ";
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
            }
            cin.ignore(numeric_limits<streamsize>::max(), '\n');

            switch (choice) {
                case 1: addProduct(); break;
                case 2: viewProducts(); break;
                case 3: updateProduct(); break;
                case 4: deleteProduct(); break;
                case 5:
                    if (orders.empty()) {
                        cout << "\nNo orders placed yet.\n";
                    } else {
                        cout << "\n--- All Placed Orders ---\n";
                        for (const auto& order : orders) {
                            order.display();
                        }
                    }
                    break;
                case 6: return;
                default: cout << "Invalid choice.\n";
            }
        }
    }
};

// ---------------------- Customer Class ----------------------
class Customer {
private:
    Cart cart;
    Admin& adminRef; // Reference to Admin to access product lists
    string currentLoggedInUser; // To store the username of the logged-in customer

public:
    // Constructor for guest customer
    Customer(Admin& admin) : adminRef(admin) {
        cart.loadFromFile("cart.txt");
        currentLoggedInUser = "Guest"; // Default for guest users
    }

    // Constructor for registered customer
    Customer(Admin& admin, const string& loggedInUser) : adminRef(admin), currentLoggedInUser(loggedInUser) {
        // You might want to load a specific cart for the logged-in user here
        // For simplicity, we'll still use a generic cart.txt for now
        cart.loadFromFile("cart.txt");
    }


    // viewCategory now accepts a vector of const Product pointers
    void viewCategory(const vector<const Product*>& products) {
        if (products.empty()) {
            cout << "No products in this category.\n";
            return;
        }

        cout << left << setw(5) << "No."
             << setw(25) << "Product Name"
             << setw(15) << "Price (Rs)"
             << setw(25) << "Subcategory"
             << "\n";
        cout << string(70, '-') << "\n";

        for (size_t i = 0; i < products.size(); ++i) {
            cout << setw(5) << (i + 1);
            products[i]->display(); // Call display through the pointer
        }
        cout << string(70, '-') << "\n";


        cout << "Enter product number to add to cart or 0 to return: ";
        int choice;
        while (!(cin >> choice)) {
            cout << "Invalid input. Please enter a number: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        if (choice > 0 && choice <= (int)products.size()) {
            const Product* selected = products[choice - 1]; // Get the pointer
            cart.addItem(CartItem(selected->getName(), selected->getPrice(), selected->getSubCategory()));
            cart.saveToFile("cart.txt");
        } else if (choice != 0) {
            cout << "Invalid product number or choice out of range.\n";
        }
    }

    // New: Search Products function
    void searchProducts() {
        cout << "\n--- Search Products ---\n";
        cout << "1. Search by Category\n2. Search by Subcategory\n3. Search by Product Name\n4. Back to Customer Menu\nChoice: ";
        int searchChoice;
        while (!(cin >> searchChoice)) {
            cout << "Invalid input. Please enter a number: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        vector<const Product*> searchResults;

        switch (searchChoice) {
            case 1: { // Search by Category
                cout << "Enter category name (New In, Men, Women, Mini Me, Fragrances): ";
                string categoryName;
                getline(cin, categoryName);
                // Convert to lowercase for case-insensitive comparison
                transform(categoryName.begin(), categoryName.end(), categoryName.begin(), ::tolower);

                if (categoryName == "new in") {
                    for (const auto& p : adminRef.newInList) searchResults.push_back(&p);
                } else if (categoryName == "men") {
                    for (const auto& p : adminRef.menList) searchResults.push_back(&p);
                } else if (categoryName == "women") {
                    for (const auto& p : adminRef.womenList) searchResults.push_back(&p);
                } else if (categoryName == "mini me") {
                    for (const auto& p : adminRef.miniMeList) searchResults.push_back(&p);
                } else if (categoryName == "fragrances") {
                    for (const auto& p : adminRef.fragranceList) searchResults.push_back(&p);
                } else {
                    cout << "Invalid category name.\n";
                    return;
                }
                break;
            }
            case 2: { // Search by Subcategory
                cout << "Enter subcategory name: ";
                string subcategoryName;
                getline(cin, subcategoryName);
                transform(subcategoryName.begin(), subcategoryName.end(), subcategoryName.begin(), ::tolower);

                // Iterate through all product lists and add matching subcategories
                for (const auto& p : adminRef.newInList) {
                    string productSub = p.getSubCategory();
                    transform(productSub.begin(), productSub.end(), productSub.begin(), ::tolower);
                    if (productSub == subcategoryName) searchResults.push_back(&p);
                }
                for (const auto& p : adminRef.menList) {
                    string productSub = p.getSubCategory();
                    transform(productSub.begin(), productSub.end(), productSub.begin(), ::tolower);
                    if (productSub == subcategoryName) searchResults.push_back(&p);
                }
                for (const auto& p : adminRef.womenList) {
                    string productSub = p.getSubCategory();
                    transform(productSub.begin(), productSub.end(), productSub.begin(), ::tolower);
                    if (productSub == subcategoryName) searchResults.push_back(&p);
                }
                for (const auto& p : adminRef.miniMeList) {
                    string productSub = p.getSubCategory();
                    transform(productSub.begin(), productSub.end(), productSub.begin(), ::tolower);
                    if (productSub == subcategoryName) searchResults.push_back(&p);
                }
                for (const auto& p : adminRef.fragranceList) {
                    string productSub = p.getSubCategory();
                    transform(productSub.begin(), productSub.end(), productSub.begin(), ::tolower);
                    if (productSub == subcategoryName) searchResults.push_back(&p);
                }
                break;
            }
            case 3: { // Search by Product Name
                cout << "Enter product name (or part of it): ";
                string productName;
                getline(cin, productName);
                transform(productName.begin(), productName.end(), productName.begin(), ::tolower);

                // Iterate through all product lists and add matching product names
                auto searchInList = [&](const auto& list) {
                    for (const auto& p : list) {
                        string pName = p.getName();
                        transform(pName.begin(), pName.end(), pName.begin(), ::tolower);
                        if (pName.find(productName) != string::npos) { // Check if name contains the search term
                            searchResults.push_back(&p);
                        }
                    }
                };

                searchInList(adminRef.newInList);
                searchInList(adminRef.menList);
                searchInList(adminRef.womenList);
                searchInList(adminRef.miniMeList);
                searchInList(adminRef.fragranceList);
                break;
            }
            case 4:
                return; // Go back to customer menu
            default:
                cout << "Invalid search choice.\n";
                return;
        }

        // Display search results using viewCategory
        if (searchResults.empty()) {
            cout << "No products found matching your search criteria.\n";
        } else {
            cout << "\n--- Search Results ---\n";
            viewCategory(searchResults); // Use existing display logic for results
        }
        cout << "----------------------\n";
    }

    // New: Filter Products by Price
    void filterProductsByPrice() {
        cout << "\n--- Filter Products by Price ---\n";
        double minPrice, maxPrice;

        cout << "Enter minimum price: ";
        while (!(cin >> minPrice) || minPrice < 0) {
            cout << "Invalid input. Please enter a non-negative number: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        cout << "Enter maximum price: ";
        while (!(cin >> maxPrice) || maxPrice < minPrice) {
            cout << "Invalid input. Please enter a number greater than or equal to minimum price: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        vector<const Product*> filteredProducts;

        // Helper lambda to add products within price range
        auto addFiltered = [&](const auto& list) {
            for (const auto& p : list) {
                if (p.getPrice() >= minPrice && p.getPrice() <= maxPrice) {
                    filteredProducts.push_back(&p);
                }
            }
        };

        addFiltered(adminRef.newInList);
        addFiltered(adminRef.menList);
        addFiltered(adminRef.womenList);
        addFiltered(adminRef.miniMeList);
        addFiltered(adminRef.fragranceList);

        if (filteredProducts.empty()) {
            cout << "No products found in the specified price range.\n";
        } else {
            cout << "\n--- Filtered Products (Rs " << fixed << setprecision(2) << minPrice << " - Rs " << maxPrice << ") ---\n";
            viewCategory(filteredProducts); // Use existing display logic
        }
        cout << "------------------------------\n";
    }

    void placeNewOrder() {
        if (cart.isEmpty()) {
            cout << "\nYour cart is empty. Cannot place an order.\n";
            return;
        }

        cout << "\n--- Confirm Order ---\n";
        cart.viewCart(); // This already shows total and items
        
        cout << "Proceed with order? (yes/no): ";
        string confirmation;
        getline(cin, confirmation);
        transform(confirmation.begin(), confirmation.end(), confirmation.begin(), ::tolower);

        if (confirmation == "yes") {
            string orderEmail;
            string orderAddress;
            regex email_regex(R"(^[^@\s]+@[^@\s]+\.[^@\s]+$)");

            if (currentLoggedInUser == "Guest") {
                cout << "Enter your email address: ";
                while (true) {
                    getline(cin, orderEmail);
                    if (regex_match(orderEmail, email_regex)) {
                        break;
                    } else {
                        cout << "Invalid email format. Please enter a valid email (e.g., user@example.com): ";
                    }
                }
                cout << "Enter your shipping address: ";
                getline(cin, orderAddress);
            } else {
                // For registered users, retrieve email from their profile
                RegisteredCustomer* regCust = adminRef.findCustomerByUsername(currentLoggedInUser);
                if (regCust) {
                    orderEmail = regCust->getEmail(); // Use the email stored in their profile
                    cout << "Using registered email: " << orderEmail << "\n";
                } else {
                    // Fallback if registered customer not found (shouldn't happen if login was successful)
                    cout << "Could not retrieve registered email. Please enter your email: ";
                    while (true) {
                        getline(cin, orderEmail);
                        if (regex_match(orderEmail, email_regex)) {
                            break;
                        } else {
                            cout << "Invalid email format. Please enter a valid email (e.g., user@example.com): ";
                        }
                    }
                }
                cout << "Enter your shipping address: ";
                getline(cin, orderAddress);
            }

            PlaceOrder newOrder(currentLoggedInUser, cart.getItems(), cart.getTotal(), orderEmail, orderAddress);
            adminRef.orders.push_back(newOrder); // Add order to admin's list
            adminRef.saveOrders(); // Save orders to file
            cart.clearCart(); // Clear cart after placing order
            cart.saveToFile("cart.txt"); // Save empty cart state
            cout << "Order placed successfully! Thank you for your purchase.\n";
        } else {
            cout << "Order cancelled.\n";
        }
        cout << "---------------------\n";
    }


    void customerMenu() {
        while (true) {
            cout << "\n--- Customer Panel (Logged in as: " << currentLoggedInUser << ") ---\n";
            cout << "1. View New In\n2. View Men\n3. View Women\n4. View Mini Me\n5. View Fragrances\n";
            cout << "6. Search Products\n7. Filter Products by Price\n";
            cout << "8. View Cart\n9. Checkout Summary\n10. Place Order\n11. Back to Main Menu\nChoice: ";
            int choice;
            while (!(cin >> choice)) {
                cout << "Invalid input. Please enter a number: ";
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
            }
            cin.ignore(numeric_limits<streamsize>::max(), '\n');

            switch (choice) {
                case 1: {
                    cout << "\n--- New In Products ---\n";
                    vector<const Product*> temp_list;
                    for (const auto& p : adminRef.newInList) {
                        temp_list.push_back(&p);
                    }
                    viewCategory(temp_list);
                    break;
                }
                case 2: {
                    cout << "\n--- Men's Products ---\n";
                    vector<const Product*> temp_list;
                    for (const auto& p : adminRef.menList) {
                        temp_list.push_back(&p);
                    }
                    viewCategory(temp_list);
                    break;
                }
                case 3: {
                    cout << "\n--- Women's Products ---\n";
                    vector<const Product*> temp_list;
                    for (const auto& p : adminRef.womenList) {
                        temp_list.push_back(&p);
                    }
                    viewCategory(temp_list);
                    break;
                }
                case 4: {
                    cout << "\n--- Mini Me Products ---\n";
                    vector<const Product*> temp_list;
                    for (const auto& p : adminRef.miniMeList) {
                        temp_list.push_back(&p);
                    }
                    viewCategory(temp_list);
                    break;
                }
                case 5: {
                    cout << "\n--- Fragrances Products ---\n";
                    vector<const Product*> temp_list;
                    for (const auto& p : adminRef.fragranceList) {
                        temp_list.push_back(&p);
                    }
                    viewCategory(temp_list);
                    break;
                }
                case 6: searchProducts(); break;
                case 7: filterProductsByPrice(); break;
                case 8: cart.viewCart(); break;
                case 9: cart.checkout(); break;
                case 10: placeNewOrder(); break;
                case 11: return;
                default: cout << "Invalid choice.\n";
            }
        }
    }
};

// ---------------------- Main ----------------------
int main() {
    Admin admin; // Admin object is initialized and loads data from files
    while (true) {
        cout << "\n========================================\n";
        cout << "     Welcome to Sapphire Online Portal\n";
        cout << "========================================\n";
        cout << "1. Admin Login\n2. Customer (Guest)\n3. Customer Registration\n4. Registered Customer Login\n5. Exit\nChoice: ";
        int choice;
        while (!(cin >> choice)) {
            cout << "Invalid input. Please enter a number: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        if (choice == 1) {
            string user, pass;
            cout << "\n--- Admin Login ---\n";
            cout << "Enter username: ";
            getline(cin, user);
            cout << "Enter password: ";
            getline(cin, pass);
            if (admin.login(user, pass)) {
                cout << "Login successful.\n";
                admin.adminMenu();
            } else {
                cout << "Invalid credentials.\n";
            }
            cout << "-------------------\n";
        } else if (choice == 2) {
            Customer cust(admin); // Guest customer
            cust.customerMenu();
        } else if (choice == 3) {
            admin.registerCustomer(); // New registration option
        } else if (choice == 4) { // New registered customer login
            string user, pass;
            cout << "\n--- Registered Customer Login ---\n";
            cout << "Enter username: ";
            getline(cin, user);
            cout << "Enter password: ";
            getline(cin, pass);
            if (admin.customerLogin(user, pass)) {
                cout << "Login successful. Welcome back, " << user << "!\n";
                Customer cust(admin, user);
                cust.customerMenu();
            } else {
                cout << "Invalid username or password.\n";
            }
            cout << "---------------------------------\n";
        }
        else if (choice == 5) {
            cout << "\nExiting program. Goodbye!\n";
            cout<<"\n For any queries contact:\n Cell no: +92(0)42 111-738-245\n Email:  wecare@sapphireonline.pk";
            break;
        } else {
            cout << "Invalid choice.\n";
        }
    }
    return 0;
}